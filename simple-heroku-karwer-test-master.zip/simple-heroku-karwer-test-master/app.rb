require 'sinatra'

get '/hi' do
  "Hello World final\n"
end

